% Post-investment offspring condition

function y=co(c,in) %input: maternal condition and investment
a1=0.5;
a2=0.5;
b1=1;
b2=0.5;
y=(a2*in.^b2 +a1*c.^b1); % output: offspring condition



end
