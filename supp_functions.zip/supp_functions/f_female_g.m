% Female logistic fitness function

function y=f_female_g(c)

bf=4.5324681549033698521644401984791;
kf=4/5;
af =3;

y=kf./(1+af*exp(-bf*c));

end
