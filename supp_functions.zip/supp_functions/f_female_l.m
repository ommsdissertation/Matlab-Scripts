% Female linear fitness function
function y=f_female_l(c)
kl=0.2;
ll=0.6;
y=kl+ll*(c);
end
