% Male convex fitness function
function y=f_male_x(c)

y=c.^2;
end

