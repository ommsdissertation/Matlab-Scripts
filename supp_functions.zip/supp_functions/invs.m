% Investment capability function

function y=invs(c) %input: mother condition
d1=1;
d2=1;
d3=20;

y=d1./(1+d2*exp(-d3*(c-0.5))); %output: investment capability

end
