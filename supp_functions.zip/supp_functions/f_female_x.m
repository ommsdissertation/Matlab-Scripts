% Female fitness function (male-convex)
function y=f_female_x(c)

 kx=0.2;
 lx=0.266;
 y=kx+lx*(c);
end
