
function [f]=realized_fitness(cm,x,i,fval,nt,phi,kappa) 

I=invs(cm);


f_m = @(x) f_male(x);
f_f = @(x) f_female(x);

if nt==1
    A=normrnd( phi, kappa);
    
    ca= @(i)co(cm,i)+A;
    
    if x==0
        f_r=2*f_f(ca(I/2));
    elseif x==1
        f_r=2*f_m(ca(I/2));
    else
        f_r=f_m(ca(i))+f_f(ca(I-i));
    end
    
    f_r=x^2*2*f_m(ca(I/2))+2*x*(1-x)*(f_m(ca(i))+f_f(ca(I-i)) )+(1-x)^2*2*f_f(ca(I/2));
        f_n=0.5^2*2*f_m(ca(I/2))+0.5^2*2*f_f(ca(I/2))+2*0.5*0.5*(f_m(ca(I/2))+f_f(ca(I/2)));

elseif nt==2
    
    B=normrnd( 0, kappa);
    ca= @(i) co(cm,i)+B;
    if x==0
        f_r=2*f_f(ca(I/2));
    elseif x==1
        f_r=2*f_m(ca(I/2));
    else
        f_r=f_m(ca(i))+f_f(ca(I-i));
    end
        f_n=0.5^2*2*f_m(ca(I/2))+0.5^2*2*f_f(ca(I/2))+2*0.5*0.5*(f_m(ca(I/2))+f_f(ca(I/2)));

    f_r=x^2*2*f_m(ca(I/2))+2*x*(1-x)*(f_m(ca(i))+f_f(ca(I-i)) )+(1-x)^2*2*f_f(ca(I/2));
   
    
elseif nt==3
    B=normrnd( - phi, kappa);
    ca= @(i) co(cm,i)+B;
    if x==0
        f_r=2*f_f(ca(I/2));
    elseif x==1
        f_r=2*f_m(ca(I/2));
    else
        f_r=f_m(ca(i))+f_f(ca(I-i));
    end
    f_r=x^2*2*f_m(ca(I/2))+2*x*(1-x)*(f_m(ca(i))+f_f(ca(I-i)) )+(1-x)^2*2*f_f(ca(I/2));
   
    f_n=0.5^2*2*f_m(ca(I/2))+0.5^2*2*f_f(ca(I/2))+2*0.5*0.5*(f_m(ca(I/2))+f_f(ca(I/2)));
end



f=[f_r,f_n,fval];
end
