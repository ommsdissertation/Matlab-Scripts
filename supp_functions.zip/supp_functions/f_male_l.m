% Male linear fitness function

function y=f_male_l(c)
y=c;
end

