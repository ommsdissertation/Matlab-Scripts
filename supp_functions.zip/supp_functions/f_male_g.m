% Male logistic fitness function
function y=f_male_g(c)

km=1;
am=80;
bm=10;
y=km./(1+am*exp(-bm*c));
end

